# kplex
An exact algorithms for the maximum k-plex problem based on branch-and-bound approach
to compile the code:

   g++ -O3 -DALL KpLeX-2021.cpp -o KpLeX -std=c++11 
   
to use it:
./KpLeX instance -x k

This instance is a file in DIMACS graph format. 
